<h1>Кино-Кино!</h1>
<script>
    let movies = [
        {title: "Овечка Долли была злая и рано умерла", description: "Никита, студент МИФИ одержим своими научными экспериментами над мышами. Один из них проходит не слишком удачно, и Никита переносится в прошлое..."},
        {title: "Корсиканец", description: "Детектив из Парижа должен отыскать на Корсике пропавшего клиента известного нотариуса. Как следует подготовившись француз прибывает на остров, который несмотря на войну группировок выглядит как рай..."},
        {title: "Вий", description: "Начало XVIII века. Картограф Джонатан Грин совершает попадает в затерянную среди непроходимых лесов деревушку..."},
        {title: "Амели", description: "Очаровательная чудачка Амели работает в кафе и делает всё, чтобы мир стал чуточку лучше, а люди, живущие в нём, счастливее..."},
        {title: "Питер FM", description: "Рассеянная ведущая модного радио теряет свой телефон, но его подбирает молодой человек, который полон решимости встретиться и вернуть находку..."},
        {title: "Бойцовский клуб", description: "Устав от скучных рабочих будней, сотрудник страховой компании ищет способ снова почувствовать себя живым. Случайный знакомый Тайлер вдохновляет его на жестокие подвиги, и вместе они создают бойцовский клуб..."},
        {title: "Рыжая Соня", description: "Соня - обычная девушка, вся семья которой была убита злобной колдуньей. Но жажда мести в девушке оказалась была настолько сильна, что боги наградили её силой, способной уничтожать врагов..."}
    ];
    function toggleDescription(movie){
        movie.showDescription = !movie.showDescription;
    }
</script>

<style>
.movie {
    margin: 10px;
    display: inline-block;
    position: relative;
}

.movie :hover .description {
    display: block;
}
.description {
    display: none;
    position: absolute;
    top:100%;
    left: 0;
    background-color: lightgray;
    padding: 10px;
    border: 1px solid darkgray;
}

</style>

{#each movies as movie}
<div class="movie">
    <h3>{movie.title}</h3>
    <p on:mouseenter={()=> toggleDescription(movie)} on:mouseleave={()=> toggleDescription(movie)}>
        {#if movie.showDescription}
            <div class="description">{movie.description}</div>
            {/if}
    </p>
</div>
{/each}